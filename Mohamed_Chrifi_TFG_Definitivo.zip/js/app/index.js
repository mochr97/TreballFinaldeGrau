
// Lectura del CSV

		const ventasData = [];
		const costeData = [];
		const beneficiosData = [];
		const labels = [];
		let options = [];
		let optionsOrigen = [];
		let tags = [];
		
		let fileInput = document.getElementById('uploadfile');

		const uploadconfirm = document.getElementById('uploadconfirm').
			addEventListener('click', () => {
			$(".btn-created").remove(); // Esto es para que se borren los botones tags al cambiar el archivo .csv
			document.getElementById('ejeid').hidden =false;

			Papa.parse(document.getElementById('uploadfile').files[0],
			{
				download: true,
				skipEmptyLines: true,
				complete: function(results){
					options = results.data[0];
					optionsOrigen = results.data[0];
					console.log("options");
					console.log(options);
					console.log("results");
					console.log(results);
					
					// for (i = 0; i < results.data.length; i++) {
					// 	// ventasData.push(results.data[i].ventas);
					// 	// costeData.push(results.data[i].coste);
					// 	// beneficiosData.push(results.data[i].beneficios);
					// 	labels.push(results.data[i].id);
					// }

					

					for (j = 0; j < options.length; j++){
						tags[j] = options[j]; // Esto almacena en 'tags' los diferentes tags del .csv
						
						if(j!=0){ // Creamos un boton para cada tag, excepto para el primer tag que sería el id (valores del eje x)
							$('#ejeid').append('<option class="opt" value="' + j +'">' + options[j] + '</option>')
						} else {
							$('#ejeid').append('<option class="opt" value="' + j +'">' + options[j] + '</option>')
						}
						options[j] = []; // Cada tag va a ser un array, con los correspondientes valores del tag
						for (i = 1; i < results.data.length; i++) {
							options[j].push(results.data[i][j]); // Con esta línea rellenamos el array correspondiente a cada tag
							// costeData.push(results.data[i].coste);
							// beneficiosData.push(results.data[i].beneficios);
							// labels.push(results.data[i].id);
							// console.log("results.data["+i+"]");
							// console.log(results.data[i]);
						} 

					}
					console.log("Mostrando el array 'options':");
					console.log(options);
				}
			});
		});


function changeAxis(){
	$('.btn-created').remove();
	Papa.parse(document.getElementById('uploadfile').files[0],
			{
				download: true,
				skipEmptyLines: true,
				complete: function(results){
					options = results.data[0];
					for (j = 0; j < options.length; j++){
						tags[j] = options[j]; // Esto almacena en 'tags' los diferentes tags del .csv
						let ejeselected = $('#ejeid option:selected').val();
						
						if(j!=ejeselected){ // Creamos un boton para cada tag, excepto para el tag seleccionado para el eje
							$('#options-container').append('<button class="btn btn-created" onclick="updateChart(' + j + ', ' + ejeselected + ')" style="margin-right:10px;">' + options[j] + '</button>'); // Añadimos aquí el onclick, y pasamos el valor de 'j' a updateChart
						}
						options[j] = []; // Cada tag va a ser un array, con los correspondientes valores del tag
						for (i = 1; i < results.data.length; i++) {
							options[j].push(results.data[i][j]); // Con esta línea rellenamos el array correspondiente a cada tag

						} 

					}
					console.log("Mostrando el array 'options':");
					console.log(options);
				}
			});
	console.log($('#ejeid option:selected').val());
}
		

		
// Configuración de Chart Js (valores de ejemplo)

	const data = {
        labels: ['Rojo', 'Azul', 'Amarillo', 'Verde', 'Morado', 'Naranja'],
        datasets: [{
        label: '# de votos (ejemplo)',
          backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]

};


// Configuracion del diseño 
	
const config = {
  type: "bar",
  data: data,
  options: {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: "Titulo de ejemplo (2022)"
      }
    }
  },
};




// Iniciar render como var

var myChart = new Chart(
	document.getElementById('myChart'),
	config
);

// PARA EL CAMBIO DE GRAFICA PRIMERO 'DESTRUIMOS' LA YA EXISTENTE
function chartTypeRein(){
	myChart.destroy();
};


// Obtenemos el valor type desde el HTML y si es 'bubble o scatter'
function chartType(type){
	if (type == 'bubble') { // No he utilizado el 'bubble' || 'scatter' porque daba problemas de diseño
	chartTypeRein();
	myChart = new Chart(
	document.getElementById('myChart'), 
	config);
	myChart.config.type = type;
	myChart.render();
	myChart.update();
	} else if (type == 'scatter'){
		
	chartTypeRein();
	myChart = new Chart(
	document.getElementById('myChart'),
	config);
	myChart.config.type = type;
	myChart.render();
	myChart.update();
		
	}
	else {
	chartTypeRein();
	myChart = new Chart("myChart", {
	type: type,  
	data: data,
	plugins: [ChartDataLabels],
	options: {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: "Titulo de ejemplo (2022)"
      }
    }
  }
	})};

};
	
function updateChart(label, eje){
	myChart.data.labels = options[eje]; // options[0] contiene los valores del tag id, es decir, los meses
	myChart.data.datasets[0].label = tags[label];
	
	myChart.data.datasets[0].data = options[label];

	myChart.update();
};



function resetChangeFile(){
	$("#ejeid option[]").remove()
	$('.btn-created').remove();
	myChart.data.labels = ['Rojo', 'Azul', 'Amarillo', 'Verde', 'Morado', 'Naranja']; // options[0] contiene los valores del tag id, es decir, los meses
	myChart.data.datasets[0].label = '# de votos (ejemplo)';
	
	myChart.data.datasets[0].data =[];
	console.log(myChart.data.datasets[0].data)
}

// Cambio de titulo y descripcion del bloque

function cambioTitulo(title) {
	myChart.config.options.plugins.title.text = title.value;
	myChart.update();
}

function cambioDescripcion(title) {
	myChart.config.data.datasets[0].label = title.value;
	myChart.update();
}


// Desacarga de la grafica

function download()
    {
    var opcion = confirm("¿Deseas realizar la descarga?");
    if (opcion == true) {
		const imageLink = document.createElement('a');
		const canvas = document.getElementById('myChart');
		imageLink.download = "TFG 2022.png";
		imageLink.href = canvas.toDataURL('image/png', 1);
		imageLink.click();
	} else {
	}
}




